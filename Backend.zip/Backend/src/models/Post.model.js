const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, index: 'text' },
  content: { type: String, required: true },
  excerpt: { type: String, index: 'text' },
  coverImage: String,
  categories: { type: [String], index: true },
  tags: [String],
  likesCount: { type: Number, default: 0, min: 0 },
  isPublished: { type: Boolean, default: true, index: true },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  comments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Comment'
  }]
}, { 
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for better performance
PostSchema.index({ createdAt: -1 });
PostSchema.index({ author: 1, createdAt: -1 });
PostSchema.index({ isPublished: 1, createdAt: -1 });
PostSchema.index({ categories: 1, isPublished: 1 });
PostSchema.index({ '$**': 'text' });

// Virtual for comments count
PostSchema.virtual('commentsCount').get(function() {
  return this.comments ? this.comments.length : 0;
});

module.exports = mongoose.model('Post', PostSchema);