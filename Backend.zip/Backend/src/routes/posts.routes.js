const express = require('express');
const router = express.Router();
const postController = require('../controllers/post.controller');
const authMiddleware = require('../middlewares/auth.middleware');

// Basic CRUD routes
router.get('/', postController.getPosts);
router.get('/user/me', authMiddleware, postController.getUserPosts);
router.get('/:id', postController.getPost);
router.post('/', authMiddleware, postController.createPost);
router.put('/:id', authMiddleware, postController.updatePost);
router.delete('/:id', authMiddleware, postController.deletePost);

// Like and comment routes
router.post('/:id/like', authMiddleware, postController.likePost);
router.post('/:id/comments', authMiddleware, postController.addComment);
router.get('/:id/comments', postController.getComments);

module.exports = router;