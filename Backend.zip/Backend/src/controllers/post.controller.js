const Post = require('../models/Post.model');
const Comment = require('../models/Comment.model');

const postController = {
  getPosts: async (req, res) => {
    try {
      const { page = 1, limit = 12, q, category } = req.query;
      const pageNum = Math.max(1, parseInt(page));
      const limitNum = Math.min(50, Math.max(1, parseInt(limit)));
      
      const query = { isPublished: true };
      if (q) query.$or = [
        { title: { $regex: q, $options: 'i' } },
        { excerpt: { $regex: q, $options: 'i' } }
      ];
      if (category) query.categories = { $in: [category] };
      
      const [posts, total] = await Promise.all([
        Post.find(query)
          .populate('author', 'name avatar')
          .select('title excerpt coverImage categories likesCount createdAt author')
          .sort({ createdAt: -1 })
          .limit(limitNum)
          .skip((pageNum - 1) * limitNum)
          .lean(),
        Post.countDocuments(query)
      ]);
        
      res.json({ 
        posts, 
        total, 
        pages: Math.ceil(total / limitNum),
        currentPage: pageNum
      });
    } catch (error) {
      console.error('getPosts error:', error);
      res.status(500).json({ message: 'Failed to fetch posts' });
    }
  },

  getPost: async (req, res) => {
    try {
      const post = await Post.findById(req.params.id)
        .populate('author', 'name avatar bio')
        .lean();
      if (!post || !post.isPublished) {
        return res.status(404).json({ message: 'Post not found' });
      }
      res.json(post);
    } catch (error) {
      console.error('getPost error:', error);
      res.status(500).json({ message: 'Failed to fetch post' });
    }
  },

  createPost: async (req, res) => {
    try {
      const post = new Post({ ...req.body, author: req.user.userId });
      await post.save();
      await post.populate('author', 'name avatar');
      res.status(201).json(post);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }, // Added comma here

  updatePost: async (req, res) => {
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ message: 'Post not found' });
      
      if (post.author.toString() !== req.user.userId) {
        return res.status(403).json({ message: 'Not authorized' });
      }
      
      Object.assign(post, req.body);
      await post.save();
      await post.populate('author', 'name avatar');
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }, // Added comma here

  deletePost: async (req, res) => {
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ message: 'Post not found' });
      
      if (post.author.toString() !== req.user.userId) {
        return res.status(403).json({ message: 'Not authorized' });
      }
      
      await Post.findByIdAndDelete(req.params.id);
      res.json({ message: 'Post deleted' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  getUserPosts: async (req, res) => {
    try {
      const { page = 1, limit = 10 } = req.query;
      const pageNum = Math.max(1, parseInt(page));
      const limitNum = Math.min(50, Math.max(1, parseInt(limit)));
      
      const [posts, total] = await Promise.all([
        Post.find({ author: req.user.userId })
          .populate('author', 'name avatar')
          .sort({ createdAt: -1 })
          .limit(limitNum)
          .skip((pageNum - 1) * limitNum)
          .lean(),
        Post.countDocuments({ author: req.user.userId })
      ]);
      
      res.json({ 
        posts, 
        total, 
        pages: Math.ceil(total / limitNum),
        currentPage: pageNum
      });
    } catch (error) {
      console.error('getUserPosts error:', error);
      res.status(500).json({ message: 'Failed to fetch user posts' });
    }
  },

  likePost: async (req, res) => {
    try {
      const userId = req.user.userId;
      const post = await Post.findById(req.params.id);
      
      if (!post) return res.status(404).json({ message: 'Post not found' });
      
      const isLiked = post.likes.includes(userId);
      const update = isLiked 
        ? { $pull: { likes: userId }, $inc: { likesCount: -1 } }
        : { $addToSet: { likes: userId }, $inc: { likesCount: 1 } };
      
      const updatedPost = await Post.findByIdAndUpdate(
        req.params.id, 
        update, 
        { new: true }
      );
      
      res.json({ 
        likesCount: updatedPost.likesCount, 
        isLiked: !isLiked 
      });
    } catch (error) {
      console.error('likePost error:', error);
      res.status(500).json({ message: 'Failed to update like' });
    }
  },

  addComment: async (req, res) => {
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ message: 'Post not found' });
      
      const comment = new Comment({
        content: req.body.content,
        author: req.user.userId,
        post: req.params.id
      });
      
      await comment.save();
      await comment.populate('author', 'name avatar');
      
      post.comments.push(comment._id);
      await post.save();
      
      res.status(201).json(comment);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  getComments: async (req, res) => {
    try {
      const { page = 1, limit = 20 } = req.query;
      const pageNum = Math.max(1, parseInt(page));
      const limitNum = Math.min(100, Math.max(1, parseInt(limit)));
      
      const [comments, total] = await Promise.all([
        Comment.find({ post: req.params.id })
          .populate('author', 'name avatar')
          .sort({ createdAt: -1 })
          .limit(limitNum)
          .skip((pageNum - 1) * limitNum)
          .lean(),
        Comment.countDocuments({ post: req.params.id })
      ]);
      
      res.json({ 
        comments, 
        total, 
        pages: Math.ceil(total / limitNum),
        currentPage: pageNum
      });
    } catch (error) {
      console.error('getComments error:', error);
      res.status(500).json({ message: 'Failed to fetch comments' });
    }
  }
};

module.exports = postController;