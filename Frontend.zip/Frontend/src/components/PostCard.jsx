import { useState, useEffect, memo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { HeartIcon, ChatBubbleLeftIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid';
import { motion } from 'framer-motion';
import api from '../utils/api';
import { toast } from 'sonner';
import clsx from 'clsx';
import SocialShare from './SocialShare';

const PostCard = memo(({ post, showActions = true, className = '' }) => {
  const [likes, setLikes] = useState(post?.likesCount || 0);
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [comments, setComments] = useState([]);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const { user } = useSelector(state => state.auth);

  useEffect(() => {
    if (user && post?.likes) {
      setIsLiked(post.likes.includes(user._id));
    }
  }, [user, post?.likes]);

  const handleLike = async () => {
    if (!user) {
      toast.error('Please login to like posts');
      return;
    }

    try {
      setIsLoading(true);
      const response = await api.post(`/posts/${post._id}/like`);
      setLikes(response.data.likesCount);
      setIsLiked(response.data.isLiked);
      toast.success(response.data.isLiked ? 'Post liked!' : 'Post unliked');
    } catch (error) {
      console.error('Error liking post:', error);
      toast.error('Failed to like post');
    } finally {
      setIsLoading(false);
    }
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.error('Please login to comment');
      return;
    }

    if (!newComment.trim()) {
      toast.error('Comment cannot be empty');
      return;
    }

    try {
      setIsLoading(true);
      await api.post(`/posts/${post._id}/comments`, { content: newComment });
      toast.success('Comment added successfully');
      fetchComments();
      setNewComment('');
    } catch (error) {
      console.error('Error adding comment:', error);
      toast.error('Failed to add comment');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchComments = async () => {
    try {
      setIsLoading(true);
      const response = await api.get(`/posts/${post._id}/comments`);
      setComments(response.data);
    } catch (error) {
      console.error('Error fetching comments:', error);
      toast.error('Failed to load comments');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleComments = () => {
    if (!showComments) {
      fetchComments();
    }
    setShowComments(!showComments);
  };

  const handleShare = () => {
    const postUrl = `${window.location.origin}/post/${post._id}`;
    navigator.clipboard.writeText(postUrl);
    toast.success('Link copied to clipboard!');
  };

  if (!post) {
    return null;
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <motion.article 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col h-full overflow-hidden transition-all duration-300 bg-white shadow-md rounded-2xl hover:shadow-xl"
    >
      {/* Cover Image */}
      <div className="relative overflow-hidden aspect-video">
        <motion.img
          initial={false}
          animate={{
            opacity: isImageLoaded ? 1 : 0,
            scale: isImageLoaded ? 1 : 1.1,
          }}
          transition={{ duration: 0.3 }}
          src={post.coverImage || 'https://via.placeholder.com/800x400'}
          alt={post.title}
          onLoad={() => setIsImageLoaded(true)}
          className="object-cover w-full h-full transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-30"></div>
      </div>

      {/* Content */}
      <div className="flex-grow p-6">
        {/* Title and Meta */}
        <Link to={`/posts/${post._id}`}>
          <h2 className="mb-2 text-xl font-bold text-gray-900 transition-colors hover:text-purple-600">
            {post.title}
          </h2>
        </Link>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-3">
          {post.categories?.map((category, index) => (
            <span
              key={index}
              className="px-3 py-1 text-xs font-medium text-purple-600 rounded-full bg-purple-50"
            >
              {category}
            </span>
          ))}
        </div>

        {/* Excerpt */}
        <p className="mb-4 text-gray-600 line-clamp-3">
          {post.excerpt || post.content?.substring(0, 150) + '...'}
        </p>

        {/* Author and Date */}
        <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <div className="flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full">
              {post.author?.name?.charAt(0).toUpperCase()}
            </div>
            <span>{post.author?.name}</span>
          </div>
          <time>{formatDate(post.createdAt)}</time>
        </div>



        {/* Title and Excerpt */}
        <Link to={`/post/${post._id}`} className="block group">
          <h2 className="mb-2 text-xl font-bold text-gray-900 transition-colors group-hover:text-purple-600">
            {post.title}
          </h2>
          {post.excerpt && (
            <p className="mb-4 text-gray-600 line-clamp-2">{post.excerpt}</p>
          )}
        </Link>

        {/* Author Info */}
        <div className="flex items-center mt-4">
          <img
            src={post.author?.avatar || `https://ui-avatars.com/api/?name=${post.author?.name}`}
            alt={post.author?.name}
            className="w-10 h-10 border-2 border-white rounded-full shadow-sm"
          />
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-900">{post.author?.name}</p>
            <p className="text-xs text-gray-500">
              {new Date(post.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })}
            </p>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="px-6 py-4 border-t border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleLike}
              disabled={isLoading}
              className={clsx(
                'flex items-center space-x-1.5 text-sm font-medium',
                isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
              )}
            >
              {isLiked ? (
                <HeartSolidIcon className="w-5 h-5" />
              ) : (
                <HeartIcon className="w-5 h-5" />
              )}
              <span>{likes}</span>
            </button>

            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-1.5 text-sm font-medium text-gray-500 hover:text-purple-600"
            >
              <ChatBubbleLeftIcon className="w-5 h-5" />
              <span>{comments.length}</span>
            </button>

            <SocialShare post={post} />
          </div>

          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className={clsx(
              'text-sm font-medium',
              isBookmarked ? 'text-purple-600' : 'text-gray-500 hover:text-purple-600'
            )}
          >
            {isBookmarked ? (
              <BookmarkSolidIcon className="w-5 h-5" />
            ) : (
              <BookmarkIcon className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Comments Section */}
        <AnimatePresence>
          {showComments && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-4 space-y-4"
            >
              {user ? (
                <form onSubmit={handleComment} className="relative">
                  <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    className="w-full px-4 py-2 pr-16 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    disabled={isLoading}
                  />
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="absolute px-3 py-1 text-sm font-medium text-white -translate-y-1/2 bg-purple-600 rounded-md right-2 top-1/2 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50"
                  >
                    Post
                  </button>
                </form>
              ) : (
                <p className="text-sm text-center text-gray-500">
                  Please{' '}
                  <Link to="/login" className="text-purple-600 hover:underline">
                    login
                  </Link>{' '}
                  to comment
                </p>
              )}

              <div className="space-y-3">
                {comments.map((comment) => (
                  <motion.div
                    key={comment._id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex space-x-3"
                  >
                    <img
                      src={comment.author?.avatar || `https://ui-avatars.com/api/?name=${comment.author?.name}`}
                      alt={comment.author?.name}
                      className="w-8 h-8 rounded-full"
                    />
                    <div className="flex-1 p-3 rounded-lg bg-gray-50">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-gray-900">
                          {comment.author?.name}
                        </span>
                        <span className="text-xs text-gray-500">
                          {new Date(comment.createdAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric'
                          })}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{comment.content}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.article>
  );
});

PostCard.displayName = 'PostCard';

export default PostCard;