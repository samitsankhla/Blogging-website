import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { toast } from 'sonner'
import DOMPurify from 'dompurify'
import { HeartIcon, ChatBubbleLeftIcon } from '@heroicons/react/24/outline'
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid'
import { setCurrentPost, setLoading } from '../features/postsSlice'
import DeleteButton from '../components/DeleteButton'
import SocialShare from '../components/SocialShare'
import api from '../utils/api'

const PostView = () => {
  const { id } = useParams()
  const { currentPost, isLoading } = useSelector(state => state.posts)
  const { user } = useSelector(state => state.auth)
  const dispatch = useDispatch()
  const [likes, setLikes] = useState(0)
  const [isLiked, setIsLiked] = useState(false)
  const [comments, setComments] = useState([])
  const [newComment, setNewComment] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    const fetchPost = async () => {
      dispatch(setLoading(true))
      try {
        const response = await api.get(`/api/posts/${id}`)
        dispatch(setCurrentPost(response.data))
        setLikes(response.data.likesCount || 0)
        setIsLiked(response.data.likes?.includes(user?._id) || false)
        fetchComments()
      } catch (error) {
        toast.error('Failed to load post')
      } finally {
        dispatch(setLoading(false))
      }
    }

    fetchPost()
  }, [id, dispatch, user])

  const fetchComments = async () => {
    try {
      const response = await api.get(`/api/posts/${id}/comments`)
      setComments(response.data || [])
    } catch (error) {
      console.error('Error fetching comments:', error)
    }
  }

  const handleLike = async () => {
    if (!user) {
      toast.error('Please login to like posts')
      return
    }

    try {
      const response = await api.post(`/api/posts/${id}/like`)
      setLikes(response.data.likesCount)
      setIsLiked(response.data.isLiked)
      toast.success(response.data.isLiked ? 'Post liked!' : 'Post unliked')
    } catch (error) {
      toast.error('Failed to like post')
    }
  }

  const handleComment = async (e) => {
    e.preventDefault()
    if (!user) {
      toast.error('Please login to comment')
      return
    }

    if (!newComment.trim()) {
      toast.error('Comment cannot be empty')
      return
    }

    try {
      setIsSubmitting(true)
      await api.post(`/api/posts/${id}/comments`, { content: newComment })
      toast.success('Comment added successfully')
      setNewComment('')
      fetchComments()
    } catch (error) {
      toast.error('Failed to add comment')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return <div className="text-center">Loading...</div>
  }

  if (!currentPost) {
    return <div className="text-center">Post not found</div>
  }

  const isAuthor = user && user._id === currentPost.author._id

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <article className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Cover Image */}
          {currentPost.coverImage && (
            <div className="relative h-64 md:h-96">
              <img 
                src={currentPost.coverImage} 
                alt={currentPost.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </div>
          )}
          
          <div className="p-6 md:p-8">
            {/* Header */}
            <div className="flex justify-between items-start mb-6">
              <div className="flex-1">
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  {currentPost.title}
                </h1>
                
                {/* Author Info */}
                <div className="flex items-center space-x-4 mb-4">
                  <img
                    src={currentPost.author?.avatar || `https://ui-avatars.com/api/?name=${currentPost.author?.name}`}
                    alt={currentPost.author?.name}
                    className="h-12 w-12 rounded-full border-2 border-white shadow-sm"
                  />
                  <div>
                    <p className="font-semibold text-gray-900">{currentPost.author?.name}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(currentPost.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                </div>
              </div>
              
              {isAuthor && (
                <div className="flex space-x-2">
                  <Link 
                    to={`/edit/${currentPost._id}`}
                    className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Edit
                  </Link>
                  <DeleteButton postId={currentPost._id} />
                </div>
              )}
            </div>
            
            {/* Categories */}
            {currentPost.categories?.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {currentPost.categories.map(category => (
                  <span 
                    key={category}
                    className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium"
                  >
                    {category}
                  </span>
                ))}
              </div>
            )}
            
            {/* Content */}
            <div 
              className="prose prose-lg max-w-none mb-8"
              dangerouslySetInnerHTML={{ 
                __html: DOMPurify.sanitize(currentPost.content) 
              }}
            />
            
            {/* Action Bar */}
            <div className="border-t border-gray-200 pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <button
                    onClick={handleLike}
                    className={`flex items-center space-x-2 text-sm font-medium transition-colors ${
                      isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
                    }`}
                  >
                    {isLiked ? (
                      <HeartSolidIcon className="h-6 w-6" />
                    ) : (
                      <HeartIcon className="h-6 w-6" />
                    )}
                    <span>{likes}</span>
                  </button>
                  
                  <div className="flex items-center space-x-2 text-sm font-medium text-gray-500">
                    <ChatBubbleLeftIcon className="h-6 w-6" />
                    <span>{comments.length}</span>
                  </div>
                  
                  <SocialShare post={currentPost} />
                </div>
              </div>
            </div>
          </div>
        </article>
        
        {/* Comments Section */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-6 md:p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">
            Comments ({comments.length})
          </h3>
          
          {/* Comment Form */}
          {user ? (
            <form onSubmit={handleComment} className="mb-8">
              <div className="flex space-x-4">
                <img
                  src={user.avatar || `https://ui-avatars.com/api/?name=${user.name}`}
                  alt={user.name}
                  className="h-10 w-10 rounded-full"
                />
                <div className="flex-1">
                  <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Write a comment..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                    rows={3}
                    disabled={isSubmitting}
                  />
                  <div className="mt-3 flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmitting || !newComment.trim()}
                      className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? 'Posting...' : 'Post Comment'}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          ) : (
            <div className="text-center py-8 bg-gray-50 rounded-lg mb-8">
              <p className="text-gray-600 mb-4">Please login to comment on this post</p>
              <Link
                to="/login"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
              >
                Login to Comment
              </Link>
            </div>
          )}
          
          {/* Comments List */}
          <div className="space-y-6">
            {comments.length === 0 ? (
              <p className="text-center text-gray-500 py-8">
                No comments yet. Be the first to comment!
              </p>
            ) : (
              comments.map((comment) => (
                <div key={comment._id} className="flex space-x-4">
                  <img
                    src={comment.author?.avatar || `https://ui-avatars.com/api/?name=${comment.author?.name}`}
                    alt={comment.author?.name}
                    className="h-10 w-10 rounded-full"
                  />
                  <div className="flex-1">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">
                          {comment.author?.name}
                        </span>
                        <span className="text-sm text-gray-500">
                          {new Date(comment.createdAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                      <p className="text-gray-700">{comment.content}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default PostView