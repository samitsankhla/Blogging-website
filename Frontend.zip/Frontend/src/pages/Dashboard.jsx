import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { 
  PlusIcon, 
  EyeIcon, 
  HeartIcon,
  ChatBubbleLeftIcon,
  DocumentTextIcon
} from '@heroicons/react/24/outline';
import { toast } from 'sonner';
import api from '../utils/api';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import PostList from '../components/PostList';

const Dashboard = () => {
  const { user } = useSelector(state => state.auth);
  const [posts, setPosts] = useState([]);
  const [stats, setStats] = useState({ totalPosts: 0, totalViews: 0, totalLikes: 0, totalComments: 0 });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadDashboard = async () => {
      setIsLoading(true);
      try {
        await Promise.all([fetchUserPosts(), fetchUserStats()]);
      } finally {
        setIsLoading(false);
      }
    };
    loadDashboard();
  }, []);

  const fetchUserPosts = async () => {
    try {
      const response = await api.get('/api/posts/user/me');
      setPosts(response.data.posts || []);
    } catch (error) {
      toast.error('Failed to load your posts');
    }
  };

  const fetchUserStats = async () => {
    try {
      const response = await api.get('/api/posts/user/me');
      const posts = response.data.posts || [];
      setStats({
        totalPosts: posts.length,
        totalViews: posts.reduce((sum, post) => sum + (post.views || 0), 0),
        totalLikes: posts.reduce((sum, post) => sum + (post.likesCount || 0), 0),
        totalComments: posts.reduce((sum, post) => sum + (post.commentsCount || 0), 0)
      });
    } catch (error) {
      toast.error('Failed to load stats');
    }
  };

  const handleDelete = async (postId) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    
    try {
      await api.delete(`/api/posts/${postId}`);
      setPosts(posts.filter(post => post._id !== postId));
      toast.success('Post deleted successfully');
      fetchUserStats();
    } catch (error) {
      toast.error('Failed to delete post');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
            <div className="h-64 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}!</h1>
            <p className="mt-1 text-sm text-gray-600">Manage your blog posts and track their performance</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <Link to="/posts">
              <Button variant="outline" className="w-full sm:w-auto">
                <DocumentTextIcon className="h-5 w-5 mr-2" />
                All Posts
              </Button>
            </Link>
            <Link to="/my-posts">
              <Button variant="outline" className="w-full sm:w-auto">
                <EyeIcon className="h-5 w-5 mr-2" />
                My Posts
              </Button>
            </Link>
            <Link to="/create">
              <Button className="w-full sm:w-auto">
                <PlusIcon className="h-5 w-5 mr-2" />
                Create New Post
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <DocumentTextIcon className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Posts</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalPosts}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <EyeIcon className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Views</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalViews}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-red-100">
                <HeartIcon className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Likes</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalLikes}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <ChatBubbleLeftIcon className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Comments</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalComments}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <Link to="/posts" className="block">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Browse All Posts</h3>
                  <p className="text-sm text-gray-600">Discover posts from the entire community</p>
                </div>
                <DocumentTextIcon className="h-8 w-8 text-purple-600" />
              </div>
            </Link>
          </Card>
          
          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
            <Link to="/my-posts" className="block">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">My Posts</h3>
                  <p className="text-sm text-gray-600">View and manage your published posts</p>
                </div>
                <EyeIcon className="h-8 w-8 text-blue-600" />
              </div>
            </Link>
          </Card>
        </div>

        {/* Posts List */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Recent Posts</h2>
          
          {posts.length === 0 ? (
            <div className="text-center py-12">
              <DocumentTextIcon className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No posts yet</h3>
              <p className="mt-1 text-sm text-gray-500">Get started by creating your first blog post.</p>
              <div className="mt-6">
                <Link to="/create">
                  <Button>
                    <PlusIcon className="h-4 w-4 mr-2" />
                    Create Post
                  </Button>
                </Link>
              </div>
            </div>
          ) : (
            <PostList posts={posts} onDelete={handleDelete} />
          )}
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;