import { motion } from 'framer-motion'
import { 
  UserGroupIcon, 
  PencilSquareIcon, 
  HeartIcon,
  ChatBubbleLeftRightIcon,
  GlobeAltIcon,
  SparklesIcon
} from '@heroicons/react/24/outline'

const About = () => {
  const features = [
    {
      icon: PencilSquareIcon,
      title: 'Rich Text Editor',
      description: 'Create beautiful blog posts with our advanced rich text editor featuring formatting, images, and more.'
    },
    {
      icon: UserGroupIcon,
      title: 'Community Driven',
      description: 'Connect with fellow writers and readers in our vibrant community of storytellers.'
    },
    {
      icon: HeartIcon,
      title: 'Engagement',
      description: 'Like, comment, and share posts to engage with content that resonates with you.'
    },
    {
      icon: ChatBubbleLeftRightIcon,
      title: 'Interactive Comments',
      description: 'Foster meaningful discussions through our interactive commenting system.'
    },
    {
      icon: GlobeAltIcon,
      title: 'Social Sharing',
      description: 'Share your favorite posts across social media platforms with one click.'
    },
    {
      icon: SparklesIcon,
      title: 'Modern Design',
      description: 'Enjoy a clean, modern interface designed for optimal reading and writing experience.'
    }
  ]

  const stats = [
    { label: 'Active Writers', value: '10K+' },
    { label: 'Published Posts', value: '50K+' },
    { label: 'Monthly Readers', value: '100K+' },
    { label: 'Countries', value: '50+' }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">BlogHub</span>
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
              A modern platform where writers share their stories, thoughts, and expertise with the world. 
              Join our community of passionate storytellers and readers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                We believe everyone has a story worth telling. BlogHub provides writers with the tools 
                and platform they need to share their thoughts, experiences, and expertise with a global audience.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Whether you're a seasoned blogger or just starting your writing journey, our platform 
                offers everything you need to create, publish, and grow your readership.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-2xl p-8 shadow-xl">
                <div className="grid grid-cols-2 gap-6">
                  {stats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className="text-2xl md:text-3xl font-bold text-purple-600 mb-2">
                        {stat.value}
                      </div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose BlogHub?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Discover the features that make BlogHub the perfect platform for writers and readers alike.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Built by Writers, for Writers
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our team consists of passionate writers, developers, and designers who understand 
              the needs of the writing community.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-2xl p-8 shadow-xl text-center"
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Join Our Community
            </h3>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Ready to start your blogging journey? Join thousands of writers who have already 
              made BlogHub their home for sharing stories and connecting with readers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/register"
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 transition-colors"
              >
                Start Writing Today
              </a>
              <a
                href="/posts"
                className="inline-flex items-center justify-center px-6 py-3 border border-purple-600 text-base font-medium rounded-md text-purple-600 bg-white hover:bg-purple-50 transition-colors"
              >
                Explore Posts
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default About